lorom

;instructions for use
;choose tilemap 0 or tilemap 1
;make sure the corresponding incbin and cursor position tables are the only
;ones that are uncommented
;you may need to move !82free depending on your project

;======================================== defines ==========================================

!82free     =       $82fde1     ;free space in bank $82

    
;======================================== hijacks ==========================================
    
org $82ed53
    jsr decjack                 ;inelegant kludge solution
    
org $82ed72
    jsr incjack
    
    
;======================================== routines =========================================
    
org !82free
    decjack:    ;missile is going up
    dec $099e
    lda $099e
    
    cmp #$0002
    bne +
    
    stz $099e
    
    +
    rts
    
    
    incjack:    ;missile is going down
    sta $099e
    
    lda $099e
    cmp #$0001
    bne +
    
    lda #$0003
    sta $099e
    
    +
    rts

;skip writing the palette on tilemap based on japanese text flag
;creates freespace from $82eded to $82ee54

org $82ecdf
    nop #3
    
org $82efd1
    nop #3

;=================================== compressed tilemaps ===================================
org $978df4
    ;0 = start game at top, rest at bottom
    ;1 = evenly spaced

    ;incbin "./options_menu__nojp_tilemap_0.map.lz"
    incbin "./options_menu__nojp_tilemap_1.map.lz"
    

;=============================== positions for cursor missile ==============================
org $82f307
    ;uncomment or comment block based on which file is included above

;cursor positions for tilemap 0 =============================
         ;x     y
;    dw  $0018,$0038, ; 0: Start game
;
;        $0018,$0090, ; 1: English text     ;no longer used
;        $0018,$0090, ; 2: Japanese text    ;no longer used
;        
;        $0018,$0090, ; 3: Controller setting mode
;        $0018,$00B0  ; 4: Special setting mode

;cursor positions for tilemap 1 ==============================
         ;x     y
    dw  $0018,$0040, ; 0: Start game

        $0018,$0090, ; 1: English text     ;no longer used
        $0018,$0090, ; 2: Japanese text    ;no longer used
        
        $0018,$0078, ; 3: Controller setting mode
        $0018,$00B0  ; 4: Special setting mode