Super Gachatroid
		ver1.14  by YP
ダウンロードありがとうございます。Unheadered (JU) ROMにパッチを当てて遊んでください。

-----------------------------------------------
ジャンル：ハーフハック
難易度：ベテラン向け


アイテムを取るまで何が出るかわからないゲームです。
ゲーム内に存在するアイテムはすべてGアイテムと言う物に変更されています。
Gアイテムに触れた時に、確率によっていずれかの装備が排出されます。
大まかな排出確率は以下のとおりです。

====R枠(15/16)====
MISSILE　（確率高い）
MORPHING BALL　（確率高い）
SUPER MISSILE
P BOMB
GRAPPLING BEAM
X-RAY
E TANK
RESERVE TANK
--ver1.14で追加↓--
MAX HEALTH	;体力回復
MAX AMMO	；弾薬回復
BLUE SUITS	；ブルースーツ状態になる
ENERGY PARTS	；2個取得でエナジータンク扱い
===================

====SR枠(1/16)====
CHARGE BEAM
ICE　（確率高い）
WAVE
SPAZER
PLAZMA
BOMB　（確率高い）
SCREW ATTACK
SPRING BALL
HI-JUMP BOOTS
SPACE JUMP
SPEED BOOSTER
VARIA SUIT
GRAVITY SUIT
==================

SRを当てて優位にゲームを進めましょう。
※引きが悪いとゲームが進行不能になる可能性があります。
　特に序盤はモーフィングボールの取得が最優先です。



-------------------更新履歴--------------------
//ver1.16//

・壁に当たっても横速度が減少しない不具合を修正
・地形の修正


//ver1.14//

・地形の修正
・Gアイテム増量（現在の総アイテム数は184個）
・アイテム排出率の調整
・R枠に以下のアイテムを追加
	MAX HEALTH	;体力回復
	MAX AMMO	；弾薬回復
	BLUE SUITS	；ブルースーツ状態になる
	ENERGY PARTS	；2個取得でエナジータンク扱い

・HARD MODE IPSを同梱
・その他


//ver1.02//

・地形の修正
・アイテムインデックスの重複を修正
・ゲームバランスの調整

・クレジットの最後のアイテムパーセンテージの表記を
　Gアイテムの総取得数に変更
　（現在の総アイテム数は178個）

-----------------------------------------------

/////////////////////////////////////////////////////////////////////////////////////


----LINK----
 改造スーパーメトロイドWiki
 https://smethack.f5.si/

 Metroid Construction
 http://www.metroidconstruction.com/index.php

----Patches----
MessageBoxV4
RepulsionBall
