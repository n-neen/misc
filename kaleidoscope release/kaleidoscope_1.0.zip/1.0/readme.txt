kaleidoscope is an oil painting

neen, 2024-25


mastery of shinespark activation (such as midar horizontal and diagonal) is strongly recommended

ability to walljump is strongly recommended



patches used which were written by others:

Crashtour99ScrewAttackBlocks.asm by Crashtour99
DoorGlitchFix_v1.2.asm by Black Falcon
FF events & tubes.IPS by JAM
FIXED_____BlackFalconSkippingCeres(andintro).ASM by Black Falcon [edited by neen]
Kejardon_Block_Remover_Commented.asm by Kejardon (commented by Oi27)
nodever_torizo_area_fix.asm by Nodever2
pjboy_bt_fix.asm by PJBoy
saveload.asm by Scyzer and Amoebaofdoom
Scrolling_Sky_v1.5.asm by Amoebaofdoom
EnemySolidBlock by Amoebaofdoom
water tilemap fix by Black Falcon and PJBoy
Block Remover by Vener
Complementary suits patch by Maddo and Smiley
Start Escape Timer with Gray Door by Oi27
ending totals by Scyzer
LessTediousTilemaps_asar.asm by Omegadragnet9


[for ingame, just include their names and not every patch used]:
Assembly:
Crashtour, Black Falcon, JAM, Kejardon, Nodever2, PJBoy, AmoebaOfDoom, Vener, Maddo, Smiley, Oi27, InsaneFirebat, Scyzer, Omegadragnet
and other assembly by neen

Tools:
SMART by Amoebaofdoom and Testrunner
Amoebacompress by Amoebaofdoom
SMACK by Mysty_Wysty
yychr
Asar
smile rf by Scyzer and Jathys
Mesen-S by Sour
super metroid disassembly by PJBoy, yuriks, InsaneFirebat, et. al


screwtank and missile concept: RT-55J, Samantha Arantes

play testing: cheesyboatride, Exister, Digital Mantra, caauyjdp, Samantha Arantes, Ironrusty

general help: Amoeba, Smiley, Oi27, RT-55J, Omegadragnet7/9, PJBoy, Tundain, InsaneFirebat, Strotlog, Mysty_Wysty, yuriks

special thanks: Digital Mantra, Alberto, RT-55J, thedagit, yuriks, jooniejoone, ironrusty, Kyzentun, Kejardon, Mysty_Wysty, Samantha Arantes, Croakomire, Amoebaofdoom, Testrunner

Jathys, without whom none of this would be possible.

Thank you all